package dao;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import Conne.Connec;
import Model.Login;

public class Dao implements DaoInter {

    private SessionFactory factory;

    public Dao() {
        factory = Connec.getSessionFact();
    }

    @Override
    public boolean signIn(int userId, String password) {
        Session session = factory.openSession();
        Login login = session.get(Login.class, userId);
        if (login != null && login.getUserPass().equals(password)) {
            session.close();
            return true;
        }
        session.close();
        return false;
    }

    @Override
    public boolean signUp(int userId, String password, String email) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Login login = new Login(userId, password, email);
        session.save(login);
        tx.commit();
        session.close();
        return true;
    }

    @Override
    public boolean removeAccount(int userId) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Login login = session.get(Login.class, userId);
        if (login != null) {
            session.delete(login);
            tx.commit();
            session.close();
            return true;
        }
        session.close();
        return false;
    }

    @Override
    public boolean updatePassword(int userId, String newPassword) {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        Login login = session.get(Login.class, userId);
        if (login != null) {
            login.setUserPass(newPassword);
            session.update(login);
            tx.commit();
            session.close();
            return true;
        }
        session.close();
        return false;
    }
}
